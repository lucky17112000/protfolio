/* global React, ReactDOM */
/* Portfolio v2 — pure black, glowing spine, scroll-linked orb, animated tree */

const { useState, useEffect, useRef, useMemo } = React;

/* ────────────────────────────────────────────────────────────
   Data
   ──────────────────────────────────────────────────────────── */
const STATS = [
  { end: 1200, suffix: "+", label: "Codeforces",      sub: "Pupil rank" },
  { end: 800,  suffix: "+", label: "LeetCode",        sub: "Solved" },
  { end: 1000, suffix: "+", label: "Algo problems",   sub: "All platforms" },
  { end: 3,    suffix: "",  label: "Projects shipped",sub: "Production" },
];

const TREE = {
  root: { label: "alamin.rahim", sub: "Backend-focused · Full-stack · CP" },
  branches: [
    {
      id: "cp", icon: "{ }", label: "Competitive Programming",
      sub: "1200+ rated · 1000+ solved",
      leaves: ["C++", "DSA", "Codeforces · 1200+", "LeetCode · 800+", "CodeChef · 2★", "Algo design"],
      hot: true,
    },
    {
      id: "be", icon: "⊡", label: "Backend Engineering",
      sub: "REST APIs · DB · containers",
      leaves: ["Node.js", "Express", "REST APIs", "PostgreSQL", "MongoDB", "Docker", ".NET / C#"],
      hot: true,
    },
    {
      id: "fs", icon: "</>", label: "Full-stack Web",
      sub: "Type-safe · deployable",
      leaves: ["TypeScript", "Next.js", "React", "Tailwind", "Git", "Vercel"],
    },
  ],
};

const PROJECTS = [
  {
    slug: "ecospark", name: "Ecospark", idx: "01",
    role: "Backend lead", year: "2025",
    desc: "Sustainability platform with a backend-first architecture. Designed fast REST APIs, normalized data models, and a reliable deploy pipeline so the frontend team could iterate without backend churn.",
    bullets: [
      "Scalable route design, lightweight responses, type-safe contracts",
      "PostgreSQL schema kept stable across frontend iterations",
      "Production-ready validation, error handling and observability",
    ],
    stack: ["Node.js","Express","TypeScript","PostgreSQL"],
    img: "assets/ecospark.jpg",
    github: "https://github.com/lucky17112000/ecospark-backend",
    live: "https://ecospark-frontend-ruddy.vercel.app/",
    tag: "Backend",
  },
  {
    slug: "tutor", name: "Tutor Tracker Dashboard", idx: "02",
    role: "Full-stack", year: "2025",
    desc: "Connects students with the right tutors through smart search, real-time communication and a fully typed Next.js frontend on top of REST APIs.",
    bullets: [
      "Normalised heterogenous data from multiple sources",
      "Responsive dashboard with no measurable performance regression",
      "Graceful handling of sparse or private profile data",
    ],
    stack: ["Next.js","TypeScript","REST","PostgreSQL"],
    img: "assets/tutor.jpg",
    github: "https://github.com/lucky17112000/assingment-4",
    live: "https://assingment-4-frontend.vercel.app/",
    tag: "Full-stack",
  },
  {
    slug: "url", name: "Dockerized URL Service", idx: "03",
    role: "Microservice", year: "Upcoming",
    desc: "Containerised URL-shortening microservice with usage analytics, health checks and rate-limit-ready design — built to scale horizontally behind a shared cache.",
    bullets: [
      "Collision-free id generation under load",
      "Observability and container health checks baked in",
      "Custom aliases, expiration and abuse-prevention next",
    ],
    stack: ["Node.js","Express","Docker","PostgreSQL"],
    img: "assets/doctor.jpg",
    github: "https://github.com/",
    live: "#",
    tag: "Upcoming",
    upcoming: true,
  },
];

const CONTACTS = [
  { l: "Email",      v: "alaminmustafa17112000@gmail.com", ic: "✉", h: "mailto:alaminmustafa17112000@gmail.com" },
  { l: "Phone",      v: "+880 1797 160 713",               ic: "☏", h: "tel:+8801797160713" },
  { l: "WhatsApp",   v: "Chat on WhatsApp",                ic: "◎", h: "https://wa.me/8801797160713" },
  { l: "GitHub",     v: "github.com/lucky17112000",        ic: "G", h: "https://github.com/lucky17112000" },
  { l: "LinkedIn",   v: "linkedin.com/in/alamin",          ic: "in",h: "https://www.linkedin.com/in/alamin-mustafa-rahim-433407271/" },
  { l: "Codeforces", v: "codeforces.com/AxonOops",         ic: "⌬", h: "https://codeforces.com/profile/AxonOops" },
];

const MARQUEE_TOP = [
  "Competitive Programmer",
  "Backend-focused",
  "Full-stack Developer",
  "Node · Postgres · Docker",
  "1200+ on Codeforces",
  "800+ on LeetCode",
];
const MARQUEE_BOT = [
  "C++",
  "TypeScript",
  "PostgreSQL",
  "Express",
  "Next.js",
  "Entity Framework",
  "Docker",
  "Vercel",
  "REST APIs",
];

/* ────────────────────────────────────────────────────────────
   Hooks
   ──────────────────────────────────────────────────────────── */
function useScrollProgress() {
  const [p, setP] = useState(0);
  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const h = document.documentElement;
        const total = h.scrollHeight - h.clientHeight;
        setP(total > 0 ? h.scrollTop / total : 0);
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);
  return p;
}

function useCount(end, start = 0, started, dur = 1600) {
  const [n, setN] = useState(start);
  useEffect(() => {
    if (!started) { setN(start); return; }
    const begin = performance.now();
    let raf;
    const tick = (t) => {
      const e = Math.min(1, (t - begin) / dur);
      const eased = 1 - Math.pow(1 - e, 3);
      setN(Math.round(start + (end - start) * eased));
      if (e < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [end, started]);
  return n;
}

function useInView(ref, threshold = 0.25, once = true) {
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    if (!ref.current) return;
    const o = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) {
        setSeen(true);
        if (once) o.disconnect();
      } else if (!once) {
        setSeen(false);
      }
    }, { threshold });
    o.observe(ref.current);
    return () => o.disconnect();
  }, []);
  return seen;
}

/* ────────────────────────────────────────────────────────────
   Components
   ──────────────────────────────────────────────────────────── */
function Spine({ progress }) {
  const pct = Math.max(0, Math.min(1, progress));
  return (
    <div className="spine" aria-hidden="true">
      <div className="ticks" />
      <div className="twin left" />
      <div className="twin right" />
      <div className="rail" />
      <div className="fill" style={{ height: `${pct * 100}%` }} />
      <div className="orb-ring r2" style={{ top: `${pct * 100}%` }} />
      <div className="orb-ring"     style={{ top: `${pct * 100}%` }} />
      <div className="orb"          style={{ top: `${pct * 100}%` }} />
      <div className="pulse" />
      <div className="pulse p2" />
      <div className="pulse p3" />
    </div>
  );
}

function Navbar() {
  const [s, setS] = useState(false);
  useEffect(() => {
    const o = () => setS(window.scrollY > 30);
    window.addEventListener("scroll", o, { passive: true });
    return () => window.removeEventListener("scroll", o);
  }, []);
  return (
    <header className={"nav " + (s ? "scrolled" : "")}>
      <a href="#hero" className="brand">
        <span className="logo">{"</>"}</span>
        ALAMIN.RAHIM
      </a>
      <nav className="nav-links">
        <a href="#about">about</a>
        <a href="#skills">skills</a>
        <a href="#projects">projects</a>
        <a href="#contact">contact</a>
        <a className="nav-cta" href="mailto:alaminmustafa17112000@gmail.com">Hire me</a>
      </nav>
    </header>
  );
}

function NodeMarker({ top, icon, children }) {
  return (
    <div
      className={"node-marker " + (icon ? "icon" : "")}
      style={{ top, position: "absolute" }}
      aria-hidden="true"
    >
      {children}
    </div>
  );
}

/* ─── HERO ─── */
function Hero() {
  const tokens = useMemo(() => [
    { t: "Competitive",    cls: "" },
    { t: "Programmer",     cls: "accent" },
    { t: "\n", br: true },
    { t: "&",              cls: "stroke" },
    { t: "Backend-focused",cls: "" },
    { t: "\n", br: true },
    { t: "Full-stack",     cls: "stroke" },
    { t: "Developer",      cls: "accent" },
  ], []);
  return (
    <section id="hero" className="hero section-anchor">
      <div className="hero-meta">ALAMIN.M.RAHIM — PORTFOLIO/2025</div>

      <span className="eyebrow reveal in">
        <span className="dot" />
        Open to backend &amp; full-stack roles
      </span>

      <h1>
        {tokens.map((tok, i) =>
          tok.br
            ? <br key={i} />
            : (
              <span
                key={i}
                className={"token " + (tok.cls || "")}
                style={{ animationDelay: `${120 + i*110}ms` }}
              >
                {tok.t}{" "}
              </span>
            )
        )}
      </h1>

      <p className="lede reveal in" style={{ transitionDelay: "650ms" }}>
        Backend-focused full-stack engineer. <strong>Codeforces 1200+</strong> · <strong>LeetCode 800+</strong> problems
        solved. Building production REST APIs with <em>Node.js</em>, <em>Express</em> and PostgreSQL.
      </p>

      <div className="cta-row reveal in" style={{ transitionDelay: "780ms" }}>
        <a href="#projects" className="btn btn-primary">
          View projects <span aria-hidden="true">→</span>
        </a>
        <a href="#skills" className="btn btn-ghost">Skill tree</a>
      </div>

      <div className="socials reveal in" style={{ transitionDelay: "880ms" }}>
        {[
          { l:"GitHub",     ic:"G",  h:"https://github.com/lucky17112000" },
          { l:"LinkedIn",   ic:"in", h:"https://www.linkedin.com/in/alamin-mustafa-rahim-433407271/" },
          { l:"Codeforces", ic:"⌬",  h:"https://codeforces.com/profile/AxonOops" },
          { l:"CodeChef",   ic:"★",  h:"https://www.codechef.com/users/lucky10000" },
          { l:"LeetCode",   ic:"▤",  h:"https://leetcode.com/" },
        ].map(s => (
          <a key={s.l} href={s.h} target="_blank" rel="noopener noreferrer" aria-label={s.l} title={s.l}>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 13, fontWeight: 700 }}>{s.ic}</span>
          </a>
        ))}
      </div>

      <div className="available reveal in" style={{ transitionDelay: "980ms" }}>
        <span className="pulse-dot" />
        <span>Currently available — response within 24h</span>
        <kbd>↵</kbd>
      </div>

      <div className="code-line reveal in" style={{ transitionDelay: "1080ms" }}>
        <span className="prompt">~/portfolio $</span>
        <span>node ./api/server.js</span>
        <span className="blink" />
      </div>
    </section>
  );
}

/* ─── ABOUT / PHOTO ─── */
function AboutSection() {
  return (
    <section id="about" className="section section-anchor">
      <NodeMarker top={"4rem"} icon>{"01"}</NodeMarker>
      <div className="section-head">
        <div>
          <p className="section-eyebrow">01 — ABOUT</p>
          <h2 className="section-title">Engineer first, <span className="accent">competitor</span> always.</h2>
        </div>
      </div>

      <div className="about-grid">
        <div className="photo-frame reveal in">
          <span className="corner tl" />
          <span className="corner tr" />
          <span className="corner bl" />
          <span className="corner br" />
          <img src="assets/profile.jpg" alt="Alamin Mustafa Rahim" />
          <div className="chip">
            <span className="left">
              <span className="dot" />
              Alamin M. Rahim
            </span>
            <span className="right">CP · .NET · BE</span>
          </div>
        </div>

        <div className="about-copy reveal in" style={{ transitionDelay: "200ms" }}>
          <h3>
            Backend-focused <span className="accent">full-stack engineer</span> with a competitive-programming brain.
          </h3>
          <p>
            I&rsquo;ve spent the last few years grinding algorithms (Codeforces 1200+, LeetCode 800+) and building
            production Node.js / Express APIs on PostgreSQL. I focus on backend systems &mdash; clean data
            contracts, fast endpoints, sane error handling &mdash; and round it out with a typed Next.js frontend
            when a project needs it end-to-end.
          </p>
          <p>
            I ship small, iterate fast, write things down, and care about code the next engineer can read without me
            in the room.
          </p>
          <div className="about-meta">
            <div className="cell">
              <div className="lbl">Based in</div>
              <div className="val">Dhaka, Bangladesh</div>
            </div>
            <div className="cell">
              <div className="lbl">Status</div>
              <div className="val"><span className="accent">●</span> Open to roles</div>
            </div>
            <div className="cell">
              <div className="lbl">Focus</div>
              <div className="val">Backend · Full-stack web</div>
            </div>
            <div className="cell">
              <div className="lbl">Languages</div>
              <div className="val">C++ · TS · JS · C#</div>
            </div>
          </div>
          <div className="cta-row" style={{ marginTop: 8 }}>
            <a href="#projects" className="btn btn-primary">See work →</a>
            <a href="assets/resume.pdf" className="btn btn-ghost" target="_blank" rel="noopener noreferrer">Resume</a>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ─── MARQUEE ─── */
function Marquee({ items, reverse, accentIndex }) {
  // double the items so the loop is seamless
  const doubled = [...items, ...items];
  return (
    <div className={"marquee " + (reverse ? "reverse" : "")} aria-hidden="true">
      <div className="marquee-track">
        {doubled.map((it, i) => (
          <span key={i} className={"marquee-item " + ((i % accentIndex) === 0 ? "accent" : ((i % 2) ? "outline" : ""))}>
            {it}
            <span className="marquee-sep" />
          </span>
        ))}
      </div>
    </div>
  );
}

/* ─── STATS ─── */
function StatsSection() {
  const ref = useRef(null);
  const started = useInView(ref, 0.4);
  return (
    <section className="section-anchor" style={{ paddingTop: "3rem", paddingBottom: "4rem" }}>
      <NodeMarker top={"30px"} icon={false} />
      <div className="stats" ref={ref}>
        <div className="scanline" />
        <div className="stat-grid">
          {STATS.map(s => <StatCell key={s.label} stat={s} started={started} />)}
        </div>
      </div>
    </section>
  );
}
function StatCell({ stat, started }) {
  const n = useCount(stat.end, 0, started, 1600);
  return (
    <div className="stat-cell">
      <div className="stat-num">{n.toLocaleString()}{stat.suffix}</div>
      <div className="stat-label">{stat.label}</div>
      <div className="stat-sub">{stat.sub}</div>
    </div>
  );
}

/* ─── SKILL TREE (graph tree: root → branches → leaves) ─── */
function SkillTree() {
  return (
    <section id="skills" className="section section-anchor">
      <NodeMarker top={"4rem"} icon>{"</>"}</NodeMarker>
      <div className="section-head">
        <div>
          <p className="section-eyebrow">02 — SKILL TREE</p>
          <h2 className="section-title">Branches of <span className="accent">expertise</span></h2>
        </div>
        <span style={{
          fontFamily: "var(--font-mono)", fontSize: 11,
          padding: "5px 12px", borderRadius: 999,
          border: "1px solid var(--accent-line)",
          background: "var(--accent-soft)",
          color: "var(--accent)",
          letterSpacing: "0.08em",
        }}>● Always growing</span>
      </div>

      <GraphTree tree={TREE} />

      <div className="tree-legend">
        <div className="item"><span className="swatch" style={{ background: "var(--accent)", boxShadow:"0 0 8px var(--accent)" }} /> Core strength</div>
        <div className="item"><span className="swatch" style={{ background: "rgba(255,255,255,0.4)" }} /> Proficient</div>
        <div className="item"><span className="swatch" style={{ background: "rgba(255,255,255,0.15)" }} /> Familiar</div>
      </div>
    </section>
  );
}

/* ─── Graph tree renderer ─── */
function GraphTree({ tree }) {
  const wrapRef    = useRef(null);
  const rootRef    = useRef(null);
  const branchRefs = useRef([]);
  const leavesRefs = useRef([]);     // top of each leaf cluster
  const leafRefs   = useRef([]);     // 2D: [branchIdx][leafIdx]

  const [paths, setPaths] = useState({ primary: [], secondary: [] });
  const [dims,  setDims]  = useState({ w: 800, h: 800 });

  const seen = useInView(wrapRef, 0.18);

  useEffect(() => {
    if (!wrapRef.current) return;

    const calc = () => {
      const wrap = wrapRef.current;
      const root = rootRef.current;
      if (!wrap || !root) return;
      const wr = wrap.getBoundingClientRect();
      setDims({ w: wr.width, h: wr.height });

      const anchor = (el, side = "bottom") => {
        const r = el.getBoundingClientRect();
        const x = r.left + r.width / 2 - wr.left;
        const y = side === "top"
          ? r.top - wr.top
          : side === "bottom"
            ? r.bottom - wr.top
            : r.top + r.height / 2 - wr.top;
        return { x, y };
      };

      const rootAnchor = anchor(root, "bottom");

      const primary = [];
      const secondary = [];

      tree.branches.forEach((b, bi) => {
        const br = branchRefs.current[bi];
        if (!br) return;
        const bTop = anchor(br, "top");
        const bBot = anchor(br, "bottom");
        // root → branch top (smooth cubic curve)
        const midY = (rootAnchor.y + bTop.y) / 2;
        primary.push({
          d: `M ${rootAnchor.x} ${rootAnchor.y}
              C ${rootAnchor.x} ${midY},
                ${bTop.x} ${midY},
                ${bTop.x} ${bTop.y}`,
          delay: 220 + bi * 140,
          hot: !!b.hot,
        });

        // branch bottom → each leaf top
        const myLeaves = leafRefs.current[bi] || [];
        myLeaves.forEach((lf, li) => {
          if (!lf) return;
          const lTop = anchor(lf, "top");
          const midLY = (bBot.y + lTop.y) / 2;
          secondary.push({
            d: `M ${bBot.x} ${bBot.y}
                C ${bBot.x} ${midLY + 6},
                  ${lTop.x} ${midLY - 4},
                  ${lTop.x} ${lTop.y}`,
            delay: 700 + bi * 140 + li * 60,
            hot: !!b.hot,
          });
        });
      });

      setPaths({ primary, secondary });
    };

    calc();
    const ro = new ResizeObserver(calc);
    ro.observe(wrapRef.current);
    window.addEventListener("resize", calc);
    return () => { ro.disconnect(); window.removeEventListener("resize", calc); };
  }, [tree]);

  return (
    <div ref={wrapRef} className="graph-tree">
      {/* SVG connector layer */}
      <svg className="graph-svg" width={dims.w} height={dims.h} viewBox={`0 0 ${dims.w} ${dims.h}`}>
        {paths.secondary.map((p, i) => (
          <path key={"s"+i} d={p.d}
            className={"graph-line thin " + (p.hot ? "hot " : "") + (seen ? "in" : "")}
            style={{ transitionDelay: `${p.delay}ms` }} />
        ))}
        {paths.primary.map((p, i) => (
          <path key={"p"+i} d={p.d}
            className={"graph-line " + (p.hot ? "hot " : "") + (seen ? "in" : "")}
            style={{ transitionDelay: `${p.delay}ms` }} />
        ))}
      </svg>

      {/* Root node */}
      <div ref={rootRef} className={"g-root " + (seen ? "in" : "")}>
        <div className="g-orb root-orb">
          <span className="orb-inner">{"</>"}</span>
        </div>
        <div className="g-label">{tree.root.label}</div>
        <div className="g-sub">{tree.root.sub}</div>
      </div>

      {/* Branches row */}
      <div className="g-branches">
        {tree.branches.map((b, bi) => (
          <div
            key={b.id}
            ref={el => { branchRefs.current[bi] = el; }}
            className={"g-branch " + (b.hot ? "hot " : "") + (seen ? "in" : "")}
            style={{ transitionDelay: `${400 + bi*120}ms` }}
          >
            <div className={"g-orb " + (b.hot ? "hot" : "")}>
              <span className="orb-inner">{b.icon}</span>
            </div>
            <div className="g-label">{b.label}</div>
            <div className="g-sub">{b.sub}</div>
          </div>
        ))}
      </div>

      {/* Leaves row (one cluster per branch, column-aligned) */}
      <div className="g-leafrow">
        {tree.branches.map((b, bi) => (
          <div
            key={b.id}
            ref={el => { leavesRefs.current[bi] = el; }}
            className="g-leafcluster"
          >
            {b.leaves.map((label, li) => (
              <span
                key={label}
                ref={el => {
                  if (!leafRefs.current[bi]) leafRefs.current[bi] = [];
                  leafRefs.current[bi][li] = el;
                }}
                className={"g-leaf " + (b.hot ? "hot " : "") + (seen ? "in" : "")}
                style={{ transitionDelay: `${900 + bi*120 + li*60}ms` }}
              >
                {label}
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── PROJECTS (alternating featured layout) ─── */
function ProjectsSection() {
  return (
    <section id="projects" className="section section-anchor">
      <NodeMarker top={"4rem"} icon>★</NodeMarker>
      <div className="section-head">
        <div>
          <p className="section-eyebrow">03 — SELECTED WORK</p>
          <h2 className="section-title">Things I&rsquo;ve <span className="accent">shipped</span></h2>
        </div>
        <a className="btn btn-ghost" href="https://github.com/lucky17112000?tab=repositories" target="_blank" rel="noopener noreferrer">
          All repos →
        </a>
      </div>
      <div style={{ position: "relative" }}>
        <ProjectsRocket count={PROJECTS.length} />
        <div className="project-list">
          {PROJECTS.map((p, i) => <FeatureProject key={p.slug} p={p} i={i} />)}
        </div>
      </div>
    </section>
  );
}

/* ─── ROCKET TRAIL ─── */
function RocketSvg() {
  // Drawn pointing UP (so rotate by tangent+90 to align with travel direction).
  return (
    <svg viewBox="0 0 40 52" width="40" height="52" style={{ display: "block", overflow: "visible" }}>
      <defs>
        <linearGradient id="rkBody" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"  stopColor="#FFFFFF" />
          <stop offset="55%" stopColor="#FFFFFF" />
          <stop offset="100%" stopColor="var(--accent-bright)" />
        </linearGradient>
        <linearGradient id="rkFlame" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor="var(--accent-bright)" />
          <stop offset="60%"  stopColor="var(--accent)" />
          <stop offset="100%" stopColor="var(--accent)" stopOpacity="0" />
        </linearGradient>
      </defs>
      {/* flame */}
      <g className="flame">
        <path d="M 14 38 Q 20 56 26 38 Q 22 44 20 44 Q 18 44 14 38 Z"
              fill="url(#rkFlame)" />
        <path d="M 16 38 Q 20 50 24 38 Q 22 42 20 42 Q 18 42 16 38 Z"
              fill="#FFFFFF" opacity="0.85" />
      </g>
      {/* fins */}
      <path d="M 10 30 L 3 39 L 10 39 Z"   fill="var(--accent)" stroke="var(--accent-bright)" strokeWidth="0.6" />
      <path d="M 30 30 L 37 39 L 30 39 Z"  fill="var(--accent)" stroke="var(--accent-bright)" strokeWidth="0.6" />
      {/* body */}
      <path d="M 20 2 Q 30 14 30 30 L 30 39 L 10 39 L 10 30 Q 10 14 20 2 Z"
            fill="url(#rkBody)"
            stroke="var(--accent)" strokeWidth="0.8" />
      {/* body stripe */}
      <path d="M 13 25 L 27 25" stroke="var(--accent)" strokeWidth="0.8" opacity="0.5" />
      {/* window */}
      <circle cx="20" cy="18" r="3.6" fill="#000" />
      <circle cx="20" cy="18" r="3.6" fill="none" stroke="var(--accent)" strokeWidth="1" />
      <circle cx="18.5" cy="16.5" r="1.2" fill="#FFFFFF" opacity="0.9" />
      {/* nose tip glow */}
      <circle cx="20" cy="2.5" r="1.2" fill="#FFFFFF" />
    </svg>
  );
}

function ProjectsRocket({ count }) {
  const wrapRef   = useRef(null);
  const pathRef   = useRef(null);
  const brightRef = useRef(null);
  const rocketRef = useRef(null);
  const [dims, setDims] = useState({ w: 800, h: 1600 });

  // Measure container
  useEffect(() => {
    if (!wrapRef.current) return;
    const measure = () => {
      const r = wrapRef.current.getBoundingClientRect();
      setDims({ w: Math.round(r.width), h: Math.round(r.height) });
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(wrapRef.current);
    return () => ro.disconnect();
  }, []);

  // Build a smooth zigzag path that hops between sides for each project.
  // Sides match project image side: 0 image-left → trail goes RIGHT
  //                                 1 image-right → trail goes LEFT
  //                                 2 image-left → trail goes RIGHT
  const sides = useMemo(() => {
    // Trail follows the IMAGE side of each project (over the darker artwork — reads better than over text body)
    // project 0: image LEFT  → side = -1
    // project 1: image RIGHT → side = +1
    // project 2: image LEFT  → side = -1
    return Array.from({ length: count }, (_, i) => (i % 2 === 0 ? -1 : +1));
  }, [count]);

  const { d, waypoints } = useMemo(() => {
    const W = dims.w, H = dims.h;
    const PAD = Math.min(60, W * 0.08);
    const pts = [{ x: W / 2, y: 20 }];
    sides.forEach((s, i) => {
      const sectionH = H / sides.length;
      const cy = i * sectionH + sectionH / 2;
      pts.push({ x: s > 0 ? W - PAD : PAD, y: cy });
    });
    pts.push({ x: W / 2, y: H - 20 });

    // smooth cubic path through points
    let path = `M ${pts[0].x} ${pts[0].y}`;
    for (let i = 1; i < pts.length; i++) {
      const a = pts[i - 1], b = pts[i];
      const dy = b.y - a.y;
      const cp1 = { x: a.x, y: a.y + dy * 0.55 };
      const cp2 = { x: b.x, y: a.y + dy * 0.45 };
      path += ` C ${cp1.x} ${cp1.y}, ${cp2.x} ${cp2.y}, ${b.x} ${b.y}`;
    }
    return { d: path, waypoints: pts };
  }, [dims, sides]);

  // Scroll-tracking: position the rocket along the path
  useEffect(() => {
    let raf = 0;
    const tick = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const wrap   = wrapRef.current;
        const rocket = rocketRef.current;
        const path   = pathRef.current;
        const bright = brightRef.current;
        if (!wrap || !rocket || !path) return;
        const r = wrap.getBoundingClientRect();
        const vh = window.innerHeight;
        // map: when wrap top is at 75% vh → p=0; when wrap bottom is at 30% vh → p=1
        const start = vh * 0.75;
        const end   = -r.height + vh * 0.30;
        const range = start - end;
        if (range <= 0) return;
        const raw = (start - r.top) / range;
        const p = Math.max(0, Math.min(1, raw));

        const len = path.getTotalLength();
        if (!len) return;
        const at = len * p;
        const pt   = path.getPointAtLength(at);
        const pt2  = path.getPointAtLength(Math.min(len, at + 1));
        const ang  = Math.atan2(pt2.y - pt.y, pt2.x - pt.x) * 180 / Math.PI;

        rocket.style.left = pt.x + "px";
        rocket.style.top  = pt.y + "px";
        rocket.style.transform = `translate(-50%, -50%) rotate(${ang + 90}deg)`;

        // bright trail = drawn portion behind the rocket
        if (bright) {
          bright.style.strokeDasharray = `${at} ${len}`;
        }
      });
    };
    tick();
    window.addEventListener("scroll", tick, { passive: true });
    window.addEventListener("resize", tick);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", tick);
      window.removeEventListener("resize", tick);
    };
  }, [d]);

  const W = dims.w, H = dims.h;
  return (
    <div ref={wrapRef} className="projects-rocket-track" aria-hidden="true">
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
        {/* ghost dashed line */}
        <path ref={pathRef} d={d} className="trail" />
        {/* solid bright trail behind rocket (drawn via dasharray) */}
        <path ref={brightRef} d={d} className="trail bright" strokeDasharray="0" />
        {/* destination marker at top — small pulsing dot */}
        <circle cx={waypoints[0].x} cy={waypoints[0].y} r="5" fill="var(--accent)" className="target" />
        <circle cx={waypoints[0].x} cy={waypoints[0].y} r="9" fill="none" stroke="var(--accent)" strokeOpacity="0.5" />
        {/* landing target at bottom — concentric rings */}
        <circle cx={waypoints[waypoints.length-1].x} cy={waypoints[waypoints.length-1].y} r="14" fill="none" stroke="var(--accent)" strokeOpacity="0.5" strokeDasharray="3 4" />
        <circle cx={waypoints[waypoints.length-1].x} cy={waypoints[waypoints.length-1].y} r="6" fill="var(--accent)" opacity="0.4" />
        <circle cx={waypoints[waypoints.length-1].x} cy={waypoints[waypoints.length-1].y} r="2.5" fill="var(--accent)" />
      </svg>
      <div ref={rocketRef} className="rocket-icon">
        <RocketSvg />
      </div>
    </div>
  );
}
function FeatureProject({ p, i }) {
  const ref = useRef(null);
  const seen = useInView(ref, 0.15);
  return (
    <article ref={ref}
      className={"project-feature " + (i % 2 ? "flip " : "") + "reveal " + (seen?"in":"")}
      style={{ transitionDelay: `${i*60}ms` }}
    >
      <div className="pf-media">
        <span className="pf-tag">{p.tag}</span>
        <span className="pf-num">{p.idx}</span>
        <img src={p.img} alt={p.name} loading="lazy" />
      </div>
      <div className="pf-body">
        <div className="pf-meta">
          <span>{p.role}</span>
          <span className="pipe">/</span>
          <span>{p.year}</span>
          <span className="pipe">/</span>
          <span>{p.stack[0]}</span>
        </div>
        <h3 className="pf-name">
          {p.name}
          <span className="arrow">↗</span>
        </h3>
        <p className="pf-desc">{p.desc}</p>
        <ul className="pf-list">
          {p.bullets.map(b => <li key={b}>{b}</li>)}
        </ul>
        <div className="pf-stack">
          {p.stack.map(t => <span key={t} className="tech">{t}</span>)}
        </div>
        <div className="pf-actions">
          {!p.upcoming && (
            <a className="btn btn-primary" href={p.live} target="_blank" rel="noopener noreferrer">
              Live ↗
            </a>
          )}
          <a className="btn btn-ghost" href={p.github} target="_blank" rel="noopener noreferrer">
            View code
          </a>
          {p.upcoming && (
            <span className="btn btn-ghost" style={{ cursor: "default", opacity: 0.7 }}>Coming soon</span>
          )}
        </div>
      </div>
    </article>
  );
}

/* ─── CONTACT ─── */
function ContactSection() {
  return (
    <section id="contact" className="section section-anchor">
      <NodeMarker top={"4rem"} icon>{"@"}</NodeMarker>
      <div className="section-head">
        <div>
          <p className="section-eyebrow">04 — CONTACT</p>
          <h2 className="section-title">Let&rsquo;s <span className="accent">connect</span></h2>
        </div>
      </div>
      <div className="contact-grid">
        <div className="contact-hero">
          <div className="status">
            <span style={{ width:8, height:8, borderRadius:"50%", background:"var(--accent)", boxShadow:"0 0 10px var(--accent)" }} />
            Open to opportunities
          </div>
          <h3>Available for backend &amp; full-stack projects</h3>
          <p>
            Looking for backend engineering and full-stack roles &mdash; especially <span style={{color:"var(--accent)"}}>Node.js,
            Express and PostgreSQL</span>. Open-source and contract work welcome.
            Response within 24 hours.
          </p>
          <div className="tags">
            <span>Full-time</span><span>Contract</span><span>Freelance</span><span>Open source</span>
          </div>
        </div>
        <div className="contact-list">
          {CONTACTS.map(c => (
            <a key={c.l} href={c.h} target="_blank" rel="noopener noreferrer" className="contact-row">
              <span className="ic">{c.ic}</span>
              <div className="meta">
                <div className="lbl">{c.l}</div>
                <div className="val">{c.v}</div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── BIG FOOTER ─── */
function BigFooter() {
  return (
    <section className="section-anchor" style={{ paddingTop: "1rem", paddingBottom: "0" }}>
      <div className="big-cta">
        <p className="eyebrow-cta">05 — LET&rsquo;S BUILD</p>
        <h2>Have an API to ship?<br/><span className="accent">Let&rsquo;s talk.</span></h2>
        <p className="sub">
          I&rsquo;m available for backend engineering roles, full-stack contract work and open-source
          collaborations &mdash; particularly Node.js, Express and PostgreSQL stacks.
        </p>
        <div className="cta-row">
          <a className="btn btn-primary" href="mailto:alaminmustafa17112000@gmail.com">
            Email me <span>→</span>
          </a>
          <a className="btn btn-ghost" href="https://wa.me/8801797160713" target="_blank" rel="noopener noreferrer">
            WhatsApp
          </a>
        </div>
      </div>

      <footer className="big-foot">
        <p className="bf-signature">ALAMIN.<span style={{color:"var(--accent)"}}>R</span></p>
        <div className="bf-cols">
          <div className="bf-col">
            <h4>Colophon</h4>
            <p className="bf-blurb">
              Backend engineer &amp; competitive programmer based in Dhaka.
              Built with <span className="accent">Next.js</span> + Tailwind, deployed on Vercel.
              Type-set in Space Grotesk, Inter and JetBrains Mono.
            </p>
            <p className="bf-blurb" style={{ marginTop: 8, color: "var(--ink-4)" }}>
              v2.0 — black-spine release · {new Date().getFullYear()}
            </p>
          </div>
          <div className="bf-col">
            <h4>Navigation</h4>
            <ul>
              <li><a href="#hero">Top</a></li>
              <li><a href="#about">About</a></li>
              <li><a href="#skills">Skill tree</a></li>
              <li><a href="#projects">Projects</a></li>
              <li><a href="#contact">Contact</a></li>
            </ul>
          </div>
          <div className="bf-col">
            <h4>Connect</h4>
            <ul>
              <li><a href="mailto:alaminmustafa17112000@gmail.com">Email <span className="ext">↗</span></a></li>
              <li><a href="https://github.com/lucky17112000" target="_blank" rel="noopener noreferrer">GitHub <span className="ext">↗</span></a></li>
              <li><a href="https://www.linkedin.com/in/alamin-mustafa-rahim-433407271/" target="_blank" rel="noopener noreferrer">LinkedIn <span className="ext">↗</span></a></li>
              <li><a href="https://wa.me/8801797160713" target="_blank" rel="noopener noreferrer">WhatsApp <span className="ext">↗</span></a></li>
            </ul>
          </div>
          <div className="bf-col">
            <h4>CP profiles</h4>
            <ul>
              <li><a href="https://codeforces.com/profile/AxonOops" target="_blank" rel="noopener noreferrer">Codeforces · 1200+</a></li>
              <li><a href="https://www.codechef.com/users/lucky10000" target="_blank" rel="noopener noreferrer">CodeChef · 2★</a></li>
              <li><a href="https://leetcode.com/" target="_blank" rel="noopener noreferrer">LeetCode · 800+</a></li>
            </ul>
          </div>
        </div>
        <div className="bf-bottom">
          <span className="live">
            <span className="dot" />
            Live · Dhaka, BD · {new Date().toLocaleString("en-US",{ timeZone:"Asia/Dhaka", hour:"2-digit", minute:"2-digit", hour12:false })}+06
          </span>
          <span>© {new Date().getFullYear()} Alamin Mustafa Rahim. All systems nominal.</span>
          <a href="#hero">back to top ↑</a>
        </div>
      </footer>
    </section>
  );
}

/* ────────────────────────────────────────────────────────────
   App root
   ──────────────────────────────────────────────────────────── */
const DEFAULT_TWEAKS = /*EDITMODE-BEGIN*/{
  "accent": "cyan",
  "spineGlow": 1,
  "grain": true,
  "ambient": true,
  "scrollOrb": true
}/*EDITMODE-END*/;

function App() {
  const progress = useScrollProgress();
  const [t, setTweak] = (window.useTweaks ? window.useTweaks(DEFAULT_TWEAKS) : [DEFAULT_TWEAKS, () => {}]);

  // Track the centered container's left offset, expose to CSS so spine-aligned
  // markers (which live inside sections) can compute their viewport-x correctly.
  useEffect(() => {
    const setVar = () => {
      const c = document.querySelector(".container");
      if (!c) return;
      const r = c.getBoundingClientRect();
      document.documentElement.style.setProperty("--container-left", `${r.left}px`);
    };
    setVar();
    window.addEventListener("resize", setVar);
    return () => window.removeEventListener("resize", setVar);
  }, []);

  const themeCls =
    t.accent === "green"  ? "theme-green" :
    t.accent === "violet" ? "theme-violet" :
    t.accent === "amber"  ? "theme-amber" : "";

  return (
    <div className={themeCls}>
      {t.ambient && (
        <>
          <div className="ambient">
            <div className="haze haze-1" />
            <div className="haze haze-2" />
            <div className="haze haze-3" />
          </div>
          <div className="vignette" />
        </>
      )}
      {t.grain && <div className="grain" />}

      <Navbar />

      <div className="spine-host">
        {t.scrollOrb && <Spine progress={progress} />}

        <main>
          <div className="container" style={{ position: "relative", zIndex: 2 }}>
            <Hero />
            <AboutSection />
          </div>

          <Marquee items={MARQUEE_TOP} accentIndex={3} />

          <div className="container" style={{ position: "relative", zIndex: 2 }}>
            <StatsSection />
            <SkillTree />
          </div>

          <Marquee items={MARQUEE_BOT} reverse accentIndex={4} />

          <div className="container" style={{ position: "relative", zIndex: 2 }}>
            <ProjectsSection />
            <ContactSection />
            <BigFooter />
          </div>
        </main>
      </div>

      {window.TweaksPanel && (
        <window.TweaksPanel title="Tweaks">
          <window.TweakSection label="Theme">
            <window.TweakRadio
              label="Accent"
              value={t.accent}
              options={["cyan", "green", "violet", "amber"]}
              onChange={v => setTweak("accent", v)}
            />
          </window.TweakSection>
          <window.TweakSection label="Effects">
            <window.TweakToggle label="Ambient haze" value={t.ambient} onChange={v => setTweak("ambient", v)} />
            <window.TweakToggle label="Film grain"   value={t.grain}   onChange={v => setTweak("grain", v)} />
            <window.TweakToggle label="Scroll orb"   value={t.scrollOrb} onChange={v => setTweak("scrollOrb", v)} />
          </window.TweakSection>
        </window.TweaksPanel>
      )}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
